# Figma Spec: Analyze AI Cards

See [`figma-spec.md`](./figma-spec.md) for detailed frame/layout/typography guidelines to build the three pipeline cards in Figma.
